# task4


f = open("input4.txt", 'r')
f1 = open("output4.txt", 'w')

N = f.readline()
my_train = []
dict1 = {}
dict2 = {}

for line in f:

    val = line[:-1].split(' ')

    my_train.append(val[0])
    n = val[-1].split(':')
    t = n[0] + n[1]
    if val[0] not in dict1:
        dict1[val[0]] = [int(t)]

    else:
        dict1[val[0]].append(int(t))

    if val[0] not in dict2:
        dict2[val[0]] = {int(t): [val[4]]}

    else:
        if int(t) in dict2[val[0]]:
            dict2[val[0]][int(t)].append(val[4])
        else:
            dict2[val[0]][int(t)] = [val[4]]


def selection_sort(arr):
    for idx in range(len(arr)):
        min = arr[idx]
        min_idx = idx
        for j in range(idx + 1, len(arr)):
            if arr[j] < min:
                min = arr[j]
                min_idx = j
        temp = arr[min_idx]
        arr[min_idx] = arr[idx]
        arr[idx] = temp
    return arr


strain = selection_sort(my_train)


def selection_sort1(arr):
    for idx in range(len(arr)):
        max = arr[idx]
        max_idx = idx
        for j in range(idx + 1, len(arr)):
            if arr[j] > max:
                max = arr[j]
                max_idx = j

        temp = arr[max_idx]
        arr[max_idx] = arr[idx]
        arr[idx] = temp
    return arr


for key, value in dict1.items():
    s = selection_sort1(value)
    dict1[key] = s

for i in strain:
    v1 = dict1[i][0]
    loc = dict2[i][v1][0]
    t2 = str(v1)
    if len(str(v1)) > 2:
        x = t2[:-2] + ':' + t2[-2] + t2[-1]
    else:
        x = '00' + ':' + t2[-2] + t2[-1]

    wr = f"{i} will departure for {loc} at {x}\n"
    dict1[i].pop(0)
    dict2[i][v1].pop(0)
    f1.write(wr)
f.close()
f1.close()

# for i in range(len(places)):

#     my_minidx = i

#     for j in range(i+1, len(places)):

#         if  places[i][0] > places[j][0]  or ( places[j][0] == places[i][0] and places[i][1]<places[j][1]):

#             temp = places[i]
#             places[i] = places[j]
#             places[j] = temp

# Instead of using two sorting we can only use this one.
