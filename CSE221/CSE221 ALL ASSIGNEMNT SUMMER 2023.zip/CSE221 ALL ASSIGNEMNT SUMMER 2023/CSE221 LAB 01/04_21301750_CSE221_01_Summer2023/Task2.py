#task2


f=open("input2.txt",'r')
f1=open("output2.txt",'w')


n=f.readline()
val=f.readline().split(' ')



arr=[]
for i in range(len(val)):
    arr.append(int(val[i]))

def bubbleSort(arr):
    f=True
    for i in range(len(arr)-1):
        if arr[i]>arr[i+1]:
            f=False

    if f==True:
        return arr
    for i in range(len(arr)-1):
        for j in range(len(arr)-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
    return arr


fin=bubbleSort(arr)
out=''

for i in fin:
    out=out+' '+str(i)
f1.write(out)
f.close()
f1.close()

#I have achieved the θ(n) complexity for this sorting algorithm by
#adding a condition which checks if the array is sorted or not.
#So, the best case scenario is that the array is already sorted and
#if that's the case then the algorithm will only run n times and will end the programme.