# Task1b


f = open("input1b.txt", "r")

f1 = open("output1b.txt", 'w')

t = f.readline()

for my_lines in f:
    values = my_lines.split(' ')
    print(values)

    if values[2] == "+":
        my_ans = int(values[1]) + int(values[3][:-1])
        my_out = f"The result of {values[1]} {values[2]} {values[3][:-1]} is {my_ans}\n"
        f1.write(my_out)


    elif values[2] == '-':
        my_ans = int(values[1]) - int(values[3][:-1])
        my_out = f"The result of {values[1]} {values[2]} {values[3][:-1]} is {my_ans}\n"
        f1.write(my_out)


    elif values[2] == '/':
        my_ans = int(values[1]) / int(values[3][:-1])
        my_out = f"The result of {values[1]} {values[2]} {values[3][:-1]} is {my_ans}\n"
        f1.write(my_out)

    else:
        ans = int(values[1]) * int(values[3][:-1])
        my_out = f"The result of {values[1]} {values[2]} {values[3][:-1]} is {my_ans}\n"
        f1.write(my_out)

f.close()
f1.close()
