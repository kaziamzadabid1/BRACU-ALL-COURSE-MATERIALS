# TASK 3


f = open('input3.txt', "r")
f1 = open('output3', 'w')

fileInput = f.readline()

dict1 = {}

values = f.readline().split()
numb = f.readline().split()

for i in range(len(values)):
    dict1[int(values[i])] = int(numb[i])

numberslst = []  # here I'm storing my num

for i in numb:
    numberslst.append(int(i))


def selection_sort(arr):
    for idx in range(len(arr)):
        max = arr[idx]
        max_idx = idx
        for j in range(idx + 1, len(arr)):
            if arr[j] > max:
                max = arr[j]
                max_idx = j

        temp = arr[max_idx]  # Swaping my values
        arr[max_idx] = arr[idx]
        arr[idx] = temp
    return arr


sortedNumbers = selection_sort(numberslst)

stored_val1 = list(dict1.keys())


def selection_sort1(arr):
    for idx in range(len(arr)):
        min = arr[idx]
        min_idx = idx
        for j in range(idx + 1, len(arr)):
            if arr[j] < min:
                min = arr[j]
                min_idx = j
        temp = arr[min_idx]
        arr[min_idx] = arr[idx]
        arr[idx] = temp
    return arr


z = selection_sort1(stored_val1)

dict2 = {}
for i in z:
    dict2[i] = dict1[i]

for i in sortedNumbers:
    for key, value in dict2.items():
        if value == i:
            line = f"ID: {key} Mark: {value}\n"
            f1.write(line)
            del dict2[key]
            break

f.close()
f1.close()


