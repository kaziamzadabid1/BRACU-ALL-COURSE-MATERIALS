#Task1a

new_file = open("input1a.txt","r")
output_file = open("output1a.txt","w")

fileInput = new_file.readlines()
new_file.close()
print(fileInput)

store = []

# print(int(fileInput[0]))


for i in range(len(fileInput)):
    x = int(fileInput[i])
    store.append(x)
print(store)


for i in store:
        if i%2 ==0:
            a=f'{i} is an Even number.\n'
            output_file.write(a)
        else:
            b = f'{i} is an odd number.\n'
            output_file.write(b)

new_file.close()
output_file.close()