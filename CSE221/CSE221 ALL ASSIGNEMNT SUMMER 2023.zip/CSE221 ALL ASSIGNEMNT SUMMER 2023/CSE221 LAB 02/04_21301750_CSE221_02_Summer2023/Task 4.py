#!/usr/bin/env python
# coding: utf-8

# In[4]:


#task 4


def merge(list1, list2):

    p1 = 0
    p2 = 0

    new_arr = []

    valLenght = len(list1)+len(list2)

    for i in range(valLenght):
        if p1 ==len(list1) or p2== len(list2):
            break

        if list1[p1] < list2[p2]:
            new_arr.append(list1[p1])
            p1 += 1
        else:
            new_arr.append(list2[p2])
            p2+= 1

    if p1>p2:
        new_arr=new_arr+list2[p2:]

    else:
        new_arr=new_arr+list1[p1:]

    return new_arr


def mergeSort(arr):

    if len(arr) <= 1:
        return arr
    else:
        mid = len(arr)//2
        a1 = mergeSort(arr[0:mid]) # write the parameter
        a2 = mergeSort(arr[mid:]) # write the parameter
        return merge(a1, a2)

arr = [1,3,20,5,11,9,2,10]
global new_arr
new_arr = []
mergeSort(arr)

print(mergeSort(arr)[-1])


# In[ ]:




