#!/usr/bin/env python
# coding: utf-8

# In[9]:


#Task1

f = open("input1.txt","r")

f3 = open("output1.txt","w")

f1 = f.readline().split(' ')
f2=f.readline().split(' ')


s = int(f1[1][:-1])
#print(s)
val=[]

print(f2)


for i in f2:
    val.append(int(i))

#print(val)

x = False

for i in range(len(val)):
    s1 = val[i]
    if x ==True:
        break

    for j in range(len(val)):
        if j!= i:
            if s1+val[j] == s:
                x=True
                f3.write(str(i+1))
                f3.write(" "+ str(j + 1)+"\n")

if x== False:
    f3.write("Impossible")

f3.close()


# In[ ]:





# In[ ]:




