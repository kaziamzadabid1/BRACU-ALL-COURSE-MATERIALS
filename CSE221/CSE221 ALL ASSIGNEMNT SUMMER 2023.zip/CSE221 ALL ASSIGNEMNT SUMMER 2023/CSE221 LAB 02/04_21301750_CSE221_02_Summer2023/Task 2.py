#!/usr/bin/env python
# coding: utf-8

# In[1]:


#task 2

# list1 = [1,3,5,7]

# list2 = [2,2,4,8]


list1=[int(x) for x in input().split(' ')]
list2=[int(x) for x in input().split(' ')]


p1 = 0

p2 = 0

lst3 = []


val = len(list1)+len(list2)

for i in range(val):
    #print(lst3)
    if p1 ==len(list1) or p2== len(list2):
        break

    if list1[p1] <list2[p2]:
            lst3.append(list1[p1])
            p1 += 1
    else:
        lst3.append(list2[p2])
        p2+= 1


if p1>p2:
    lst3=lst3+list2[p2:]

else:
    lst3=lst3+list1[p1:]
print(lst3)


# In[ ]:




