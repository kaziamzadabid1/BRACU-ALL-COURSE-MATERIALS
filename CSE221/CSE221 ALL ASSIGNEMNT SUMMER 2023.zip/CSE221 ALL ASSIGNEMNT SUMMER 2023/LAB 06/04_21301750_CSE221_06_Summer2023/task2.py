
#task2

class Graph:
  def __init__(self):
    self.graph = {}

  def addEdge(self, u, v, w):
    self.graph[u].append((v, w))

  def d_BFS(self, s):
    cost = [99999] * (len(self.graph)+1)
    parent = [None] * (len(self.graph)+1)
    visited = [False] * (len(self.graph)+1)
    queue = []
    queue.append(s)
    visited[s] = True
    cost[s] = 0


    while queue:
      s = queue.pop(0)

      for i in self.graph[s]:
        if visited[i[0]] == False:
          queue.append(i[0])
          visited[i[0]] = True
        if (cost[s] + i[1]) < cost[i[0]]:
          cost[i[0]] =  (cost[s] + i[1])
          parent[i[0]] = s

    return cost


with open("input2.txt", "r") as f2:
  n, m = f2.readline().strip().split(" ")
  n = int(n)
  m = int(m)

  g1 = Graph()

  for i in range(1, n+1):
    g1.graph[i] = []

  for i in range(m):
    u, v, w = f2.readline().strip().split()
    u = int(u)
    v = int(v)
    w = int(w)

    g1.addEdge(u, v, w)

  s1, s2 = f2.readline().split(" ")

  arr1 = g1.d_BFS(int(s1))
  arr2 = g1.d_BFS(int(s2))


  time = 99999
  node = 0

  for i in range(1, n+1):
    if arr1[i] != 99999 and arr2[i] != 99999:
      if max(arr1[i], arr2[i]) < time:
        time = max(arr1[i], arr2[i])
        node = i

with open("output2.txt", "w") as f2_out:
  if time != 99999:
    f2_out.write(f"Time {time}\nNode {node}")
  else:
    f2_out.write("Impossible")