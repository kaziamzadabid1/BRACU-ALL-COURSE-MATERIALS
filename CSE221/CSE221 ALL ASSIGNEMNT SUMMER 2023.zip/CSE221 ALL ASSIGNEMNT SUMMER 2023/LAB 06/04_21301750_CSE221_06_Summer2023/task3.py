#task3

class Graph:
  def __init__(self):
    self.graph = {}

  def addEdge(self, u, v, w):
    self.graph[u].append((v, w))

  def d_BFS(self, s):
    cost = [99999] * (len(self.graph)+1)
    parent = [None] * (len(self.graph)+1)
    visited = [False] * (len(self.graph)+1)
    queue = []
    queue.append(s)
    visited[s] = True
    cost[s] = 0


    while queue:
      s = queue.pop(0)

      for i in self.graph[s]:
        if visited[i[0]] == False:
          queue.append(i[0])
          visited[i[0]] = True
        if max(cost[s], i[1]) < cost[i[0]]:
          cost[i[0]] =  max(cost[s], i[1])
          parent[i[0]] = s

    return cost[-1]

# - - - - - - - - - - - -- - - - - - - - - - -

with open("input3.txt", "r") as f1:
  n, m = f1.readline().strip().split(" ")
  n = int(n)
  m = int(m)

  g1 = Graph()

  for i in range(1, n+1):
    g1.graph[i] = []

  for i in range(m):
    u, v, w = f1.readline().strip().split()
    u = int(u)
    v = int(v)
    w = int(w)

    g1.addEdge(u, v, w)

  cost_lvl = g1.d_BFS(1)

with open("output3.txt", "w") as f3_out:
  if cost_lvl != 99999:
    f3_out.write(str(cost_lvl))
  else:
    f3_out.write("Impossible")