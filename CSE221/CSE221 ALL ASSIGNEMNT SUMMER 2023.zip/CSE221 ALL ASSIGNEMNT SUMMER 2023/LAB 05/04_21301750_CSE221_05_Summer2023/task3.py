# %%
f1 = open("input3.txt", "r")
f2 = open("output3.txt", "w")

N, M = map(int, f1.readline().split())

def dfs_visit(node, graph, visited, stack):
    visited[node] = True
    for neighbor in graph[node]:
        if not visited[neighbor]:
            dfs_visit(neighbor, graph, visited, stack)
    stack.append(node)

def dfs_scc(node, graph, visited, scc):
    visited[node] = True
    scc.append(node)
    for neighbor in graph[node]:
        if not visited[neighbor]:
            dfs_scc(neighbor, graph, visited, scc)

def transpose_graph(graph):
    transposed_graph = {node: [] for node in graph}
    for node in graph:
        for neighbor in graph[node]:
            transposed_graph[neighbor].append(node)
    return transposed_graph

def strongly_connected_components(graph):
    num_nodes = len(graph)
    visited = [False] * (num_nodes + 1)
    stack = []
    for node in range(1, num_nodes + 1):
        if not visited[node]:
            dfs_visit(node, graph, visited, stack)

    transposed_graph = transpose_graph(graph)
    visited = [False] * (num_nodes + 1)
    strongly_connected_components = []

    while stack:
        node = stack.pop()
        if not visited[node]:
            scc = []
            dfs_scc(node, transposed_graph, visited, scc)
            strongly_connected_components.append(scc)

    return strongly_connected_components


graph = {i: [] for i in range(1, N + 1)}
for i in range(M):
    u, v = map(int, f1.readline().split())
    graph[u].append(v)


sccs = strongly_connected_components(graph)

for i in sccs:
    print(" ".join(str(node) for node in i), file=f2)

f1.close()
f2.close()











