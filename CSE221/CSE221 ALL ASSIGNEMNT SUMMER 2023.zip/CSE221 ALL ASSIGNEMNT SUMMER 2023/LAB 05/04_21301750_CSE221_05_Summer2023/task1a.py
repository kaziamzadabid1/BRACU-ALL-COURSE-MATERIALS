# %%
f1 = open("input1a.txt","r")
f2 = open("output1a.txt","w")
N,M = map(int,f1.readline().split())
prereq = [tuple(map(int,f1.readline().split())) for i in range(M)]
graph = {i:[] for i in range(1,N+1)}
for i in prereq:
    graph[i[0]].append(i[1])
def topologicalSortUtil(course,visited,stack):
    visited.append(course)
    for i in graph[course]:
        if i not in visited:
            topologicalSortUtil(i,visited,stack)
    stack.insert(0,course)
def dfs_topological_sort(num_of_course,prereq):
    visited = []
    stack = []
    for key in graph:
        if key not in visited:
            topologicalSortUtil(key,visited,stack)
    if len(stack)!=N:
        print("IMPOSSIBLE",file=f2)
    for i in stack:
        print(i,end=" ",file=f2)
dfs_topological_sort(N,prereq)


