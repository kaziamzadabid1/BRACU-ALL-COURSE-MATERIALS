# %%
f1 = open("input1b.txt","r")
f2 = open("output1b.txt","w")
N,M = map(int,f1.readline().split())
prereq = [tuple(map(int,f1.readline().split())) for i in range(M)]
def bfs_topological_sort(num_courses,prereq):
    graph = {i:[] for i in range(1,num_courses+1)}
    inDegree = {i:0 for i in range(1,num_courses+1)}
    for i in prereq:
      graph[i[0]].append(i[1])
      inDegree[i[1]]+=1
    queue = [i for i in graph if inDegree[i]==0]
    output = []

    while queue:
       current_vertex = queue.pop(0)
       output.append(current_vertex) 
       for neighbour in graph[current_vertex]:
          inDegree[neighbour]-=1
          if inDegree[neighbour]==0:
             queue.append(neighbour)
    if len(output)!=len(graph):
       print("IMPOSSIBLE",file=f2)
    for i in output:
       print(i, end=" ",file=f2)
bfs_topological_sort(N,prereq)




