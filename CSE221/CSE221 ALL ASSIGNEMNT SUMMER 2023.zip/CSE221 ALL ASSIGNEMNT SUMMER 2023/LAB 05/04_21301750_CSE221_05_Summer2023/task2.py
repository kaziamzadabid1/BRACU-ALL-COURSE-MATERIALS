# %%
import heapq

f1 = open("input2.txt", "r")
f2 = open("output2.txt", "w")
N, M = map(int, f1.readline().split())
prereq = [tuple(map(int, f1.readline().split())) for i in range(M)]

def topological_sort(num_courses, prereq):
    graph = {i: [] for i in range(1, num_courses + 1)}
    inDegree = {i: 0 for i in range(1, num_courses + 1)}

    for i in prereq:
        graph[i[0]].append(i[1])
        inDegree[i[1]] += 1

    priority_queue = [i for i in graph if inDegree[i] == 0]
    heapq.heapify(priority_queue)
    output = []

    while priority_queue:
        current_vertex = heapq.heappop(priority_queue)
        output.append(current_vertex)

        for neighbour in graph[current_vertex]:
            inDegree[neighbour] -= 1
            if inDegree[neighbour] == 0:
                heapq.heappush(priority_queue, neighbour)

    if len(output) != len(graph):
        print("IMPOSSIBLE", file=f2)
    for i in output:
        print(i,end=' ',file=f2)

topological_sort(N, prereq)
f1.close()
f2.close()



